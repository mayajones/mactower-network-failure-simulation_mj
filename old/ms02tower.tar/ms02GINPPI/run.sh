ms02 -i merged_PPIGIN_2014Jan20.tab -o output/_m202.merged.network.tab -d 2 
