ms02 -i _test.tab -o output/_m202.merged.network.tab -d 2
